// ============================================
// ENTITÀ DI GIOCO - Mago e Creature
// ============================================

// Classe base per tutte le entità mobili
class Entity {
    constructor(x, y) {
        this.id = Utils.generateId();
        this.x = x;
        this.y = y;
        this.hp = 100;
        this.maxHp = 100;
        this.speed = 100;
        this.state = EntityState.IDLE;
        this.path = null;
        this.pathIndex = 0;
        this.target = null;
        this.shield = 0;
        this.color = '#ffffff';
        this.radius = 10;
    }
    
    getCell() {
        return Utils.pixelToGrid(this.x, this.y);
    }
    
    takeDamage(amount, source = null) {
        // Prima consuma lo scudo
        if (this.shield > 0) {
            if (this.shield >= amount) {
                this.shield -= amount;
                return 0;
            } else {
                amount -= this.shield;
                this.shield = 0;
            }
        }
        
        this.hp -= amount;
        if (this.hp <= 0) {
            this.hp = 0;
            this.state = EntityState.DEAD;
        }
        return amount;
    }
    
    heal(amount) {
        this.hp = Math.min(this.hp + amount, this.maxHp);
    }
    
    addShield(amount) {
        this.shield += amount;
    }
    
    isAlive() {
        return this.state !== EntityState.DEAD && this.hp > 0;
    }
    
    moveTo(targetX, targetY, gameMap, pathfinder) {
        const startCell = this.getCell();
        const endCell = Utils.pixelToGrid(targetX, targetY);
        
        this.path = pathfinder.findPath(
            startCell.col, startCell.row,
            endCell.col, endCell.row,
            this.intelligence || 0
        );
        
        if (this.path) {
            this.pathIndex = 0;
            this.state = EntityState.MOVING;
            return true;
        }
        return false;
    }
    
    update(dt, gameMap) {
        if (this.state === EntityState.MOVING && this.path) {
            this.followPath(dt, gameMap);
        }
    }
    
    followPath(dt, gameMap) {
        if (!this.path || this.pathIndex >= this.path.length) {
            this.state = EntityState.IDLE;
            this.path = null;
            return;
        }
        
        const targetCell = this.path[this.pathIndex];
        const targetPos = Utils.gridToPixel(targetCell.col, targetCell.row);
        
        const dx = targetPos.x - this.x;
        const dy = targetPos.y - this.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < 5) {
            // Raggiungi il prossimo waypoint
            this.pathIndex++;
            if (this.pathIndex >= this.path.length) {
                this.state = EntityState.IDLE;
                this.path = null;
            }
            return;
        }
        
        // Applica modificatore velocità terreno
        const cell = this.getCell();
        const speedMult = gameMap.getSpeedMultiplier(cell.col, cell.row);
        const actualSpeed = this.speed * speedMult;
        
        // Muovi verso il target
        const moveX = (dx / dist) * actualSpeed * dt;
        const moveY = (dy / dist) * actualSpeed * dt;
        
        this.x += moveX;
        this.y += moveY;
    }
    
    render(ctx) {
        // Cerchio base
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.5)';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Scudo (se presente)
        if (this.shield > 0) {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius + 4, 0, Math.PI * 2);
            ctx.strokeStyle = '#00bfff';
            ctx.lineWidth = 3;
            ctx.stroke();
        }
        
        // Barra HP
        this.renderHpBar(ctx);
    }
    
    renderHpBar(ctx) {
        const barWidth = this.radius * 2;
        const barHeight = 4;
        const x = this.x - barWidth / 2;
        const y = this.y - this.radius - 10;
        
        // Sfondo
        ctx.fillStyle = '#333';
        ctx.fillRect(x, y, barWidth, barHeight);
        
        // HP
        const hpPercent = this.hp / this.maxHp;
        ctx.fillStyle = hpPercent > 0.5 ? '#2ecc71' : hpPercent > 0.25 ? '#f39c12' : '#e74c3c';
        ctx.fillRect(x, y, barWidth * hpPercent, barHeight);
        
        // Scudo
        if (this.shield > 0) {
            const shieldPercent = Math.min(this.shield / this.maxHp, 1);
            ctx.fillStyle = '#00bfff';
            ctx.fillRect(x, y - 2, barWidth * shieldPercent, 2);
        }
    }
    
    renderPath(ctx) {
        if (!this.path || this.pathIndex >= this.path.length) return;
        
        ctx.strokeStyle = 'rgba(255, 255, 0, 0.5)';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        
        for (let i = this.pathIndex; i < this.path.length; i++) {
            const pos = Utils.gridToPixel(this.path[i].col, this.path[i].row);
            ctx.lineTo(pos.x, pos.y);
        }
        
        ctx.stroke();
        ctx.setLineDash([]);
    }
}

// ============================================
// IL MAGO (Giocatore)
// ============================================

class Mage extends Entity {
    constructor(x, y) {
        super(x, y);
        this.hp = CONFIG.MAGE.hp;
        this.maxHp = CONFIG.MAGE.hp;
        this.speed = CONFIG.MAGE.speed;
        this.intelligence = CONFIG.MAGE.intelligence;
        this.color = CONFIG.MAGE.color;
        this.radius = 12;
        
        this.mana = CONFIG.STARTING_MANA;
        this.maxMana = 200;
        this.attackRange = CONFIG.MAGE.attackRange;
        
        this.inventory = []; // Pozioni raccolte
        this.selectedSpell = null;
        this.castTimer = 0;
    }
    
    update(dt, gameMap) {
        super.update(dt, gameMap);
        
        // Rigenera mana (lentamente)
        this.mana = Math.min(this.mana + CONFIG.MANA_REGEN * dt, this.maxMana);
        
        // Timer cast
        if (this.castTimer > 0) {
            this.castTimer -= dt;
        }
    }
    
    canCast(spell) {
        return this.mana >= spell.manaCost && this.castTimer <= 0;
    }
    
    spendMana(amount) {
        if (this.mana >= amount) {
            this.mana -= amount;
            return true;
        }
        return false;
    }
    
    gainMana(amount) {
        this.mana = Math.min(this.mana + amount, this.maxMana);
    }
    
    render(ctx) {
        // Disegna il mago con un design distintivo
        
        // Cerchio principale
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        
        // Bordo luminoso
        ctx.strokeStyle = '#d4a5ff';
        ctx.lineWidth = 3;
        ctx.stroke();
        
        // Cappello da mago (triangolo)
        ctx.beginPath();
        ctx.moveTo(this.x, this.y - this.radius - 12);
        ctx.lineTo(this.x - 8, this.y - this.radius + 2);
        ctx.lineTo(this.x + 8, this.y - this.radius + 2);
        ctx.closePath();
        ctx.fillStyle = '#6a0dad';
        ctx.fill();
        
        // Scudo
        if (this.shield > 0) {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius + 6, 0, Math.PI * 2);
            ctx.strokeStyle = 'rgba(0, 191, 255, 0.7)';
            ctx.lineWidth = 4;
            ctx.stroke();
        }
        
        // Indicatore di cast
        if (this.castTimer > 0) {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius + 10, 0, Math.PI * 2 * (1 - this.castTimer / 0.5));
            ctx.strokeStyle = '#ffd700';
            ctx.lineWidth = 2;
            ctx.stroke();
        }
        
        // Barre HP e Mana
        this.renderHpBar(ctx);
        this.renderManaBar(ctx);
    }
    
    renderManaBar(ctx) {
        const barWidth = this.radius * 2;
        const barHeight = 3;
        const x = this.x - barWidth / 2;
        const y = this.y - this.radius - 5;
        
        ctx.fillStyle = '#222';
        ctx.fillRect(x, y, barWidth, barHeight);
        
        const manaPercent = this.mana / this.maxMana;
        ctx.fillStyle = '#00d4ff';
        ctx.fillRect(x, y, barWidth * manaPercent, barHeight);
    }
}

// ============================================
// CREATURE EVOCATE
// ============================================

class Creature extends Entity {
    constructor(x, y, type) {
        super(x, y);
        
        const stats = CreatureTypes[type];
        this.type = type;
        this.name = stats.name;
        this.hp = stats.hp;
        this.maxHp = stats.hp;
        this.damage = stats.damage;
        this.attackSpeed = stats.attackSpeed;
        this.speed = stats.speed;
        this.manaCost = stats.manaCost;
        this.intelligence = stats.intelligence;
        this.color = stats.color;
        this.radius = stats.radius;
        this.armorPiercing = stats.armorPiercing || false;
        this.armorReduction = stats.armorReduction || 0;
        
        this.attackCooldown = 0;
        this.target = null;
    }
    
    update(dt, gameMap, towers) {
        super.update(dt, gameMap);
        
        // Cooldown attacco
        if (this.attackCooldown > 0) {
            this.attackCooldown -= dt;
        }
        
        // Se ha un target, verifica se è ancora valido
        if (this.target) {
            if (!this.target.isAlive || !this.target.isAlive()) {
                this.target = null;
                this.state = EntityState.IDLE;
            }
        }
        
        // Se è in stato ATTACKING, attacca
        if (this.state === EntityState.ATTACKING && this.target) {
            this.attackTarget(dt);
        }
    }
    
    setTarget(target, gameMap, pathfinder) {
        this.target = target;
        this.moveTo(target.x, target.y, gameMap, pathfinder);
    }
    
    attackTarget(dt) {
        if (!this.target || !this.target.isAlive()) return;
        
        const dist = Utils.entityDistance(this, this.target);
        const attackRange = (this.radius + (this.target.radius || 20) + 10);
        
        if (dist <= attackRange) {
            // In range di attacco
            if (this.attackCooldown <= 0) {
                const damage = this.target.takeDamage(this.damage);
                GameLog.damage(`${this.name} infligge ${damage} danni a ${this.target.name}`);
                this.attackCooldown = 1 / this.attackSpeed;
            }
        } else {
            // Deve avvicinarsi
            this.state = EntityState.MOVING;
        }
    }
    
    // Override per verificare se abbiamo raggiunto il target
    followPath(dt, gameMap) {
        super.followPath(dt, gameMap);
        
        // Se abbiamo un target, verifica distanza
        if (this.target && this.target.isAlive()) {
            const dist = Utils.entityDistance(this, this.target);
            const attackRange = (this.radius + (this.target.radius || 20) + 10);
            
            if (dist <= attackRange) {
                this.state = EntityState.ATTACKING;
                this.path = null;
            }
        }
    }
    
    render(ctx) {
        // Colore base
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.5)';
        ctx.lineWidth = 1;
        ctx.stroke();
        
        // Indicatore tipo (per distinguere larve da giganti)
        if (this.type === 'GIANT') {
            // Disegna un simbolo di forza
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 12px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('G', this.x, this.y);
        }
        
        // Scudo
        if (this.shield > 0) {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius + 3, 0, Math.PI * 2);
            ctx.strokeStyle = '#00bfff';
            ctx.lineWidth = 2;
            ctx.stroke();
        }
        
        // Barra HP solo se danneggiato
        if (this.hp < this.maxHp) {
            this.renderHpBar(ctx);
        }
    }
}
