// ============================================
// GAME - Logica principale
// ============================================

class Game {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        
        // Dimensioni
        this.resize();
        
        // Sistemi
        this.map = new GameMap(CONFIG.GRID_WIDTH, CONFIG.GRID_HEIGHT);
        this.pathfinder = new Pathfinder(this.map);
        this.spellSystem = new SpellSystem();
        
        // Entità
        this.mage = null;
        this.creatures = [];
        this.towers = [];
        
        // Stato gioco
        this.state = 'playing';  // playing, won, lost
        this.selectedSpell = null;
        this.showTowerRanges = false;
        this.mouseX = 0;
        this.mouseY = 0;
        
        // Timing
        this.lastTime = 0;
        this.accumulator = 0;
        this.fixedDt = 1 / 60;
    }
    
    resize() {
        this.canvas.width = CONFIG.GRID_WIDTH * CONFIG.TILE_SIZE;
        this.canvas.height = CONFIG.GRID_HEIGHT * CONFIG.TILE_SIZE;
    }
    
    // Carica un livello
    loadLevel(levelData) {
        // Reset
        this.creatures = [];
        this.towers = [];
        this.state = 'playing';
        this.selectedSpell = null;
        GameLog.clear();
        
        // Carica mappa
        this.map.loadLevel(levelData.map);
        
        // Crea torri
        for (const towerDef of levelData.towers) {
            const tower = createTower(towerDef.type, towerDef.col, towerDef.row);
            this.towers.push(tower);
        }
        
        // Aggiorna danger map
        this.map.updateDangerMap(this.towers);
        
        // Crea mago
        const magePos = Utils.gridToPixel(levelData.mageStart.col, levelData.mageStart.row);
        this.mage = new Mage(magePos.x, magePos.y);
        
        // Log
        GameLog.log(`Livello "${levelData.name}" caricato`);
        GameLog.log(`Obiettivo: raggiungi il tesoro!`);
        
        this.updateUI();
    }
    
    // Game loop
    start() {
        this.lastTime = performance.now();
        requestAnimationFrame((time) => this.loop(time));
    }
    
    loop(currentTime) {
        const dt = (currentTime - this.lastTime) / 1000;
        this.lastTime = currentTime;
        
        // Fixed timestep per fisica/logica
        this.accumulator += dt;
        while (this.accumulator >= this.fixedDt) {
            this.update(this.fixedDt);
            this.accumulator -= this.fixedDt;
        }
        
        // Render
        this.render();
        
        // Continua loop
        requestAnimationFrame((time) => this.loop(time));
    }
    
    // Update logica
    update(dt) {
        if (this.state !== 'playing') return;
        
        // Update mago
        if (this.mage && this.mage.isAlive()) {
            this.mage.update(dt, this.map);
            
            // Verifica vittoria (mago sul tesoro)
            const mageCell = this.mage.getCell();
            if (this.map.getTile(mageCell.col, mageCell.row) === Tile.TREASURE) {
                this.win();
            }
        } else if (this.mage && !this.mage.isAlive()) {
            this.lose();
        }
        
        // Update creature
        for (let i = this.creatures.length - 1; i >= 0; i--) {
            const creature = this.creatures[i];
            
            if (creature.isAlive()) {
                creature.update(dt, this.map, this.towers);
            } else {
                // Rimuovi creatura morta e guadagna un po' di mana (meccanica anime)
                // In questo caso le creature del mago non danno mana, ma i nemici sì
                this.creatures.splice(i, 1);
            }
        }
        
        // Ottieni tutti i nemici per le torri
        const allEnemies = this.mage ? [this.mage, ...this.creatures] : [...this.creatures];
        
        // Update torri
        for (let i = this.towers.length - 1; i >= 0; i--) {
            const tower = this.towers[i];
            
            if (tower.isAlive()) {
                tower.update(dt, allEnemies.filter(e => e.isAlive()));
            } else {
                // Torre distrutta
                this.towers.splice(i, 1);
                // Aggiorna danger map
                this.map.updateDangerMap(this.towers);
            }
        }
        
        // Update sistema incantesimi
        this.spellSystem.update(dt);
        
        // Update UI
        this.updateUI();
    }
    
    // Render
    render() {
        // Clear
        this.ctx.fillStyle = '#1a1a2e';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Mappa
        this.map.render(this.ctx);
        
        // Range torri (se abilitato)
        for (const tower of this.towers) {
            tower.render(this.ctx, this.showTowerRanges);
        }
        
        // Creature
        for (const creature of this.creatures) {
            if (creature.isAlive()) {
                creature.render(this.ctx);
                // Debug: mostra path
                // creature.renderPath(this.ctx);
            }
        }
        
        // Mago
        if (this.mage && this.mage.isAlive()) {
            this.mage.render(this.ctx);
            this.mage.renderPath(this.ctx);
        }
        
        // Effetti incantesimi
        this.spellSystem.render(this.ctx);
        
        // Preview incantesimo selezionato
        if (this.selectedSpell && this.mage) {
            const isValid = this.spellSystem.isInCastRange(
                this.mage, this.mouseX, this.mouseY, this.selectedSpell
            );
            this.spellSystem.renderCastRange(this.ctx, this.mage, this.selectedSpell);
            renderSpellPreview(this.ctx, this.selectedSpell, this.mouseX, this.mouseY, isValid);
        }
        
        // Messaggio stato gioco
        if (this.state === 'won') {
            this.renderMessage('VITTORIA!', '#2ecc71');
        } else if (this.state === 'lost') {
            this.renderMessage('SCONFITTA', '#e74c3c');
        }
    }
    
    renderMessage(text, color) {
        this.ctx.fillStyle = 'rgba(0,0,0,0.7)';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.ctx.fillStyle = color;
        this.ctx.font = 'bold 48px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(text, this.canvas.width / 2, this.canvas.height / 2);
        
        this.ctx.fillStyle = '#fff';
        this.ctx.font = '20px Arial';
        this.ctx.fillText('Premi R per ricominciare', this.canvas.width / 2, this.canvas.height / 2 + 50);
    }
    
    // Azioni giocatore
    moveMage(targetX, targetY) {
        if (!this.mage || !this.mage.isAlive()) return;
        
        this.mage.moveTo(targetX, targetY, this.map, this.pathfinder);
    }
    
    summonCreature(type) {
        if (!this.mage || !this.mage.isAlive()) return;
        
        const stats = CreatureTypes[type];
        const totalCost = stats.manaCost * stats.spawnCount;
        
        if (this.mage.mana < totalCost) {
            GameLog.log('Mana insufficiente per evocare');
            return;
        }
        
        this.mage.spendMana(totalCost);
        
        // Spawn creature vicino al mago
        for (let i = 0; i < stats.spawnCount; i++) {
            const offset = {
                x: Utils.randomFloat(-30, 30),
                y: Utils.randomFloat(-30, 30)
            };
            
            const creature = new Creature(
                this.mage.x + offset.x,
                this.mage.y + offset.y,
                type
            );
            
            this.creatures.push(creature);
        }
        
        GameLog.summon(`Evocato: ${stats.spawnCount}x ${stats.name}`);
    }
    
    castSpell(targetX, targetY) {
        if (!this.selectedSpell || !this.mage) return;
        
        const success = this.spellSystem.castSpell(
            this.selectedSpell,
            this.mage,
            targetX,
            targetY,
            this
        );
        
        if (success) {
            this.selectedSpell = null;
            this.updateSpellButtons();
        }
    }
    
    selectSpell(spellType) {
        if (this.selectedSpell === spellType) {
            this.selectedSpell = null;
        } else {
            this.selectedSpell = spellType;
        }
        this.updateSpellButtons();
    }
    
    // Click su una posizione della mappa
    handleClick(x, y, isRightClick) {
        if (this.state !== 'playing') return;
        
        if (isRightClick) {
            // Click destro: muovi il mago
            this.moveMage(x, y);
        } else {
            // Click sinistro
            if (this.selectedSpell) {
                // Lancia incantesimo
                this.castSpell(x, y);
            } else {
                // Verifica se clicchiamo su una torre (per dare ordine alle creature)
                const clickedTower = this.getTowerAt(x, y);
                if (clickedTower) {
                    this.orderCreaturesToAttack(clickedTower);
                }
            }
        }
    }
    
    getTowerAt(x, y) {
        for (const tower of this.towers) {
            const dist = Utils.distance(x, y, tower.x, tower.y);
            if (dist <= tower.radius + 10) {
                return tower;
            }
        }
        return null;
    }
    
    orderCreaturesToAttack(target) {
        const activeCreatures = this.creatures.filter(c => c.isAlive());
        
        if (activeCreatures.length === 0) {
            GameLog.log('Nessuna creatura da comandare');
            return;
        }
        
        for (const creature of activeCreatures) {
            creature.setTarget(target, this.map, this.pathfinder);
        }
        
        GameLog.log(`${activeCreatures.length} creature attaccano ${target.name}`);
    }
    
    // UI
    updateUI() {
        if (!this.mage) return;
        
        document.getElementById('mana-display').textContent = 
            `Mana: ${Math.floor(this.mage.mana)}`;
        document.getElementById('hp-display').textContent = 
            `HP: ${Math.floor(this.mage.hp)}${this.mage.shield > 0 ? ` (+${Math.floor(this.mage.shield)})` : ''}`;
        
        // Abilita/disabilita bottoni
        this.updateSpellButtons();
        this.updateSummonButtons();
    }
    
    updateSpellButtons() {
        document.querySelectorAll('.spell-btn').forEach(btn => {
            const spellType = btn.dataset.spell.toUpperCase();
            const spell = SpellTypes[spellType];
            
            btn.disabled = !this.mage || this.mage.mana < spell.manaCost;
            btn.classList.toggle('active', this.selectedSpell === spellType);
        });
    }
    
    updateSummonButtons() {
        document.querySelectorAll('.summon-btn').forEach(btn => {
            const summonType = btn.dataset.summon.toUpperCase();
            const stats = CreatureTypes[summonType];
            const totalCost = stats.manaCost * stats.spawnCount;
            
            btn.disabled = !this.mage || this.mage.mana < totalCost;
        });
    }
    
    // Stati fine gioco
    win() {
        this.state = 'won';
        GameLog.log('HAI VINTO! Il tesoro è tuo!');
    }
    
    lose() {
        this.state = 'lost';
        GameLog.death('Il Mago è caduto... Game Over');
    }
    
    restart() {
        this.loadLevel(Levels.tutorial);
    }
    
    // Toggle debug
    toggleDangerView() {
        this.map.toggleDangerView();
    }
    
    toggleTowerRanges() {
        this.showTowerRanges = !this.showTowerRanges;
    }
}
